#ifndef ALL_H
#define ALL_H

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <assert.h>

#include "edo_solver.h"
#include "functions.h"
#include "integration.h"
#include "interpolation.h"
#include "vectors.h"

#endif